﻿using ForgeAir.Playout.Views;
using System.Windows;

namespace ForgeAir.Playout
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            InitializeComponent();
        }
    }
}