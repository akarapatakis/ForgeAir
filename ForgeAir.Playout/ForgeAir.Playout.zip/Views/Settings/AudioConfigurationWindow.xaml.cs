﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ForgeAir.Playout.Views.Settings
{
    /// <summary>
    /// Interaction logic for AudioConfigurationWindow.xaml
    /// </summary>
    public partial class AudioConfigurationWindow : HandyControl.Controls.Window
    {
        public AudioConfigurationWindow()
        {
            InitializeComponent();
            pageViewer.Content = new Pages.AudioIOSetup();
        }

        private void sideMenu_SelectionChanged(object sender, HandyControl.Data.FunctionEventArgs<object> e)
        {
            if (vstItem.IsSelected)
            {
                pageViewer.Content = new Pages.AudioVSTConfigPage();

            }
            else if (audioTweaksItem.IsSelected)
            {
                pageViewer.Content = new Pages.AudioTweaksPage();

            }
            else if (devicesItem.IsSelected)
            {
                pageViewer.Content = new Pages.AudioIOSetup();
            }
        }
    }
}
