﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ForgeAir.Core.Services.AudioPlayout.Players.Interfaces;

namespace ForgeAir.Core.Services.AudioPlayout
{
    class AudioService
    {
        IPlayer player;


    }
}
