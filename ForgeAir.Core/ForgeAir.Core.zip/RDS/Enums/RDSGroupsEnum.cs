﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeAir.Core.RDS.Enums
{
    public enum RDSGroupsEnum
    {
        PS = 0,
        RT = 1,
        TA = 2,
        TP = 3,
        CT = 4,
    }
}
