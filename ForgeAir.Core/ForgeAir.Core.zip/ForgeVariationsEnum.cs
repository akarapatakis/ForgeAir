﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeAir.Core
{
    public enum ForgeVariationsEnum
    {
        ForgeAir = 0,
        ForgeVision = 1,
    }
}
