﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeAir.Core.Streaming.Enums
{
    public enum DataUpdateMethodEnum
    {
        None = 0,
        FTP = 1,
        LocalFile = 2,
        Butt = 3
    }
}
