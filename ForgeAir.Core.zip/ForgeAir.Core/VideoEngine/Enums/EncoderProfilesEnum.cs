﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForgeAir.Core.VideoEngine.Enums
{
    public enum eAVEncH265VProfile
    {
        eAVEncH265VProfile_unknown = 0,
        eAVEncH265VProfile_Main_420_8 = 1,
        eAVEncH265VProfile_Main_420_10 = 2,
        eAVEncH265VProfile_Main_420_12 = 3,
        eAVEncH265VProfile_Main_422_10 = 4,
        eAVEncH265VProfile_Main_422_12 = 5,
        eAVEncH265VProfile_Main_444_8 = 6,
        eAVEncH265VProfile_Main_444_10 = 7,
        eAVEncH265VProfile_Main_444_12 = 8,
        eAVEncH265VProfile_Monochrome_12 = 9,
        eAVEncH265VProfile_Monochrome_16 = 10,
        eAVEncH265VProfile_MainIntra_420_8 = 11,
        eAVEncH265VProfile_MainIntra_420_10 = 12,
        eAVEncH265VProfile_MainIntra_420_12 = 13,
        eAVEncH265VProfile_MainIntra_422_10 = 14,
        eAVEncH265VProfile_MainIntra_422_12 = 15,
        eAVEncH265VProfile_MainIntra_444_8 = 16,
        eAVEncH265VProfile_MainIntra_444_10 = 17,
        eAVEncH265VProfile_MainIntra_444_12 = 18,
        eAVEncH265VProfile_MainIntra_444_16 = 19,
        eAVEncH265VProfile_MainStill_420_8 = 20,
        eAVEncH265VProfile_MainStill_444_8 = 21,
        eAVEncH265VProfile_MainStill_444_16 = 22
    };
}
