﻿using ForgeAir.Core.Services.Interfaces;
using ForgeAir.Core.Tracks.Enums;
using ForgeAir.Database;
using Microsoft.EntityFrameworkCore;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ForgeAir.Core.Services
{
    public class Repository<T> where T : class
    {
        private readonly ForgeAirDbContext _context;

        public Repository(ForgeAirDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<int> GetCountOf(ModelTypesEnum model)
        {
            return model switch
            {
                ModelTypesEnum.Track => await _context.Tracks.CountAsync(),
                ModelTypesEnum.Artist => await _context.Artists.CountAsync(),
                ModelTypesEnum.ArtistTrack => await _context.ArtistTracks.CountAsync(),
                ModelTypesEnum.Category => await _context.Category.CountAsync(),
                _ => 0,
            };
        }

        public async Task<bool> ArtistExists(Database.Models.Artist artist)
        {
            return await _context.Artists.AnyAsync(e => e.Name == artist.Name);
        }

        public async Task<T?> GetSpecificById(ModelTypesEnum model, int id)
        {

            return model switch
            {
                ModelTypesEnum.Track => await _context.Tracks
                    .Include(t => t.TrackArtists)
                        .ThenInclude(ta => ta.Artist)
                    .AsNoTracking()
                    .FirstOrDefaultAsync(t => t.Id == id) as T,

                ModelTypesEnum.Artist => await _context.Artists.FindAsync(id) as T,
                ModelTypesEnum.ArtistTrack => await _context.ArtistTracks.FirstOrDefaultAsync(p => p.TrackId == id) as T,
                ModelTypesEnum.Category => await _context.Category.FindAsync(id) as T,
                _ => null,
            };
        }

        public async Task<T?> GetSpecificByName(ModelTypesEnum model, string name)
        {
            return model switch
            {
                ModelTypesEnum.Track => await _context.Tracks.FirstOrDefaultAsync(p => p.Title == name) as T,
                ModelTypesEnum.Artist => await _context.Artists.FirstOrDefaultAsync(p => p.Name == name) as T,
                ModelTypesEnum.Category => await _context.Category.FirstOrDefaultAsync(p => p.Name == name) as T,
                _ => null,
            };
        }

        public async Task<List<T>> GetAll(ModelTypesEnum model)
        {
            return model switch
            {
                ModelTypesEnum.Track => await _context.Tracks
                    .Include(t => t.TrackArtists)
                    .ThenInclude(ta => ta.Artist)
                    .AsNoTracking()
                    .ToListAsync() as List<T>,

                ModelTypesEnum.Artist => await _context.Artists
                    .AsNoTracking()
                    .ToListAsync() as List<T>,

                ModelTypesEnum.ArtistTrack => await _context.ArtistTracks
                    .AsNoTracking()
                    .ToListAsync() as List<T>,

                ModelTypesEnum.Category => await _context.Category
                    .AsNoTracking()
                    .ToListAsync() as List<T>,
                ModelTypesEnum.FX => await _context.Fx
                    .AsNoTracking()
                    .ToListAsync() as List<T>,
                _ => new List<T>(),
            };
        }


        public async Task<List<DTO.Artist>> SearchArtistAsync(string name)
        {
            try
            {
                string sql = "SELECT Id, Name FROM Artists WHERE Name LIKE @name";
                return await _context.Database
                    .SqlQueryRaw<DTO.Artist>(sql, new MySqlParameter("@name", $"%{name}%"))
                    .AsNoTracking()
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error searching artist: {ex.Message}");
                return new List<DTO.Artist>();
            }
        }
    }
}
