﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;
using System.Timers;
using ForgeAir.Core.Shared;
using ManagedBass;

namespace ForgeAir.Core.AudioEngine
{
    public class AudioStreamInfo
    {
        public AudioStreamInfo() { }

        public void UpdateVUMeters()
        {

        }
    }
}
